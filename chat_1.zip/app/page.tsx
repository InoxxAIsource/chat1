import AIAssistantUI from "../components/AIAssistantUI"

export default function Page() {
  return <AIAssistantUI />
}
